<p align="center">
<img src="https://telegra.ph/file/e0bc28185977299bf5d2c.jpg" alt="PROJECT 01" height= "300" width="300"/>


</p>
<p align="center">
<a href="#"><img title="WIZARD MULTI DEVICE" src="https://img.shields.io/badge/WIZARD MULTI DEVICE-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Ajmal-Achu"><img title="Author" src="https://img.shields.io/badge/Author-AJMAL-red.svg?style=for-the-badge&logo=github"></a>
<p align="center">
<a href="https://github.com/Ajmal-Achu/followers"><img title="Followers" src="https://img.shields.io/github/followers/Ajmal-Achu?color=blue&style=flat-square"></a>
<a href="https://github.com/Ajmal-Achu"><img title="Stars" src="https://img.shields.io/github/stars/Ajmal-Achu/Wizard-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Ajmal-Achu/Wizard-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Ajmal-Achu/Wizard-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Ajmal-Achu/Wizard-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Ajmal-Achu/Wizard-MD?color=red&style=flat-square"></a>
<a href="https://github.com/Ajmal-Achu/Wizard-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Ajmal-Achu/Wizard-MD?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/Ajmal-Achu/Wizard-MD"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/Ajmal-Achu/Wizard-MD/"><img title="Size" src="https://img.shields.io/github/repo-size/Ajmal-Achu/Wizard-MD?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FAjmal-Achu%2FWizard-MD&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/Ajmal-Achu/Wizard-MD/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</P>
</div>
---


<div align="center">

### DEPLOY THROUGH HEROKU

<a href="https://wizard-md-deployer.vercel.app/"><img align="center" src="https://telegra.ph/file/c7a44f94bc788d4d6478f.jpg" alt="Fork and deploy" height="50" width="200" /></a>
</div>

---


### FOR TERMUX USER
1. Type below given commands one by one in Termux.
```
apt update && apt upgrade
apt install bash
apt install libwebp
apt install git-y
apt install nodejs -y
apt install ffmpeg -y
apt install wget
apt install imagemagick -y
git clone https://github.com/Ajmal-Achu/Wizard-MD
cd Wizard-MD
rm -r session.json
node.
```  

### Preview bot

- [x] Welcome <details><summary>Screenshot</summary><img src="https://telegra.ph/file/e7adc19143c17cebece3c.jpg"></details>
- [x] Catalog Menu <details><summary>Screenshot</summary><img src="https://telegra.ph/file/7c33c8442aa5c551309ef.jpg"></details>
- [x] Setmenu <details><summary>Screenshot</summary><img src="https://telegra.ph/file/5094eb58f19a49543443a.jpg"></details>
- [x] Document Menu <details><summary>Screenshot</summary><img src="https://telegra.ph/file/8f50df332fe50495a4853.jpg"></details>

And Many More Features Are Available 😊


<!---->
# Thanks to
<a href="https://github.com/Ajmal-Achu"><img src="https://github.com/Ajmal-Achu.png?size=100" width="100" height="100"></a> | [<img src="https://telegra.ph/file/0d160eade24b0ad32ee12.jpg" width="100" height="100">](https://github.com/Ajmal-Achu/Wizard-MD) 
---|---
[AJMAL](https://github.com/Ajmal-Achu)  | [ABHI](https://github.com/Ajmal-Achu/Wizard-MD)
DEVELOPER| FOR HELP |
<a href="https://github.com/V1P3R-X"><img src="https://github.com/V1P3R-X.png?size=100" width="100" height="100"></a> | [![WIZARD MD](https://github.com/Neeraj-X0.png?size=100)](https://github.com/Neeraj-X0) 
[V1P3R-X](https://github.com/V1P3R-X)  | [Neeraj-X0](https://github.com/Neeraj-X0)
CONTRIBUTOR| CONTRIBUTOR |
<a href="https://github.com/Lord-official"><img src="https://github.com/Lord-official.png?size=100" width="100" height="100"></a> | [![WIZARD MD](http://github.com/SafwanGanz.png?size=100)](http://github.com/SafwanGanz) 
[LORD-SER](https://github.com/Lord-official)  | [SAFWAN GANZ](https://github.com/SafwanGanz)
FOR HELP | OWNER OF WHATS-FELIX MD|
<a href="https://github.com/ᴡ4ʟᴋ36.ᴇғx"><img src="https://github.com/ᴡ4ʟᴋ36.ᴇғx.png?size=100" width="100" height="100"></a> | [![WIZARD MD](http://github.com/Alien-alfa.png?size=100)](http://github.com/Alien-alfa)  
[ANEES](https://github.com/ᴡ4ʟᴋ36.ᴇғx) | [ALIEN ALFA](https://Alien-alfa)
MODIFYING AS PUBLIC | HEAD OF ALIEN ALFA WA BOT DEV COMMUNITY |

